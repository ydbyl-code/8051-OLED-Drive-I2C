#include <STC89C5xRC.H>
#include <OLEDmax.c>
#include "TP1.h"

void main()
{
	OLEDstart();
	while(1)
	{
		OLEDDrawPicture(IMG_DATA);
	}
	
}