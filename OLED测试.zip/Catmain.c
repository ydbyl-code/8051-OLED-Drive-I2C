#include <STC89C5xRC.H>
#include <OLEDpro.c>
#include "catY_1.h"
#include "catY_2.h"
#include "catY_3.h"
#include "catY_4.h"
#include "catY_5.h"
#include "catY_6.h"
#include "catY_7.h"
//#include "catY_8.h"
//#include "catY_9.h"

void main()
{
	OLEDstart();
	while(1)
	{
		OLEDDrawPicture(IMG1_DATA);
		OLEDDrawPicture(IMG2_DATA);
		OLEDDrawPicture(IMG3_DATA);
		OLEDDrawPicture(IMG4_DATA);
		OLEDDrawPicture(IMG5_DATA);
		OLEDDrawPicture(IMG6_DATA);
		OLEDDrawPicture(IMG7_DATA);
		//OLEDDrawPicture(IMG8_DATA);
		//OLEDDrawPicture(IMG9_DATA);
	}
}