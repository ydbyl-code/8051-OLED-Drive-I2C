#include <STC89C5xRC.H>
#include <OLEDmax.c>
#include "kun1.h"
#include "kun2.h"
#include "kun3.h"
#include "kun4.h"
#include "kun5.h"
#include "kun6.h"
#include "kun7.h"

void main()
{
	OLEDstart();
	while(1)
	{
		OLEDDrawPicture(IMG1_DATA);
		OLEDDrawPicture(IMG2_DATA);
		OLEDDrawPicture(IMG3_DATA);
		OLEDDrawPicture(IMG4_DATA);
		OLEDDrawPicture(IMG5_DATA);
		OLEDDrawPicture(IMG6_DATA);
		OLEDDrawPicture(IMG7_DATA);
		OLEDDrawPicture(IMG6_DATA);
		OLEDDrawPicture(IMG5_DATA);
		OLEDDrawPicture(IMG4_DATA);
		OLEDDrawPicture(IMG3_DATA);
		OLEDDrawPicture(IMG2_DATA);
	}
}